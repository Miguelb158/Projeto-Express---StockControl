m234 = ("oi")

print(m234)